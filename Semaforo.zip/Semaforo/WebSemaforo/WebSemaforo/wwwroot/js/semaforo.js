﻿var objetoSemaforo = new Object();
objetoSemaforo.divVerde = "#verde";
objetoSemaforo.divAmarelo = "#amarelo";
objetoSemaforo.divVermelho = "#vermelho";
objetoSemaforo.labelTimeSemafoto = "#timeSemaforo";
objetoSemaforo.labeltimeSemaforoPedestre = "#timeSemaforoPedestre";
objetoSemaforo.tempo = 0;


// 3 vermelho
// 2 amarelo 
// 1 verde
objetoSemaforo.EstagioSemaforo = 1;

objetoSemaforo.MotaEstagioSemafotos = function () {



    switch (objetoSemaforo.EstagioSemaforo) {
        case 1:
        default:
            objetoSemaforo.RemoveClasse();
            $(objetoSemaforo.divVerde).addClass("semaforoVerdeLigado");
            objetoSemaforo.EstagioSemaforo = 2;
            setTimeout(objetoSemaforo.MotaEstagioSemafotos, 10000);
            clearTimeout(objetoSemaforo.timeSetControl);
            break;
        case 2:
            objetoSemaforo.RemoveClasse();
            $(objetoSemaforo.divAmarelo).addClass("semaforoAmareloLigado");
            objetoSemaforo.EstagioSemaforo = 3;
            setTimeout(objetoSemaforo.MotaEstagioSemafotos, 5000);
            clearTimeout(objetoSemaforo.timeSetControl);
            break;
        case 3:
            objetoSemaforo.RemoveClasse();
            $(objetoSemaforo.divVermelho).addClass("semaforoVermelhoLigado");
            objetoSemaforo.EstagioSemaforo = 1;
            setTimeout(objetoSemaforo.MotaEstagioSemafotos, 10000);
            clearTimeout(objetoSemaforo.timeSetControl);
            break;
    }

    objetoSemaforo.IniciaTime();

}

objetoSemaforo.RemoveClasse = function () {

    $(objetoSemaforo.divVerde).removeClass("semaforoVerdeLigado");
    $(objetoSemaforo.divAmarelo).removeClass("semaforoAmareloLigado");
    $(objetoSemaforo.divVermelho).removeClass("semaforoVermelhoLigado");


}

objetoSemaforo.IniciaTime = function () {

    if (objetoSemaforo.EstagioSemaforo == 2) {
        if (objetoSemaforo.tempo == 0) {
            objetoSemaforo.tempo = 15

        }
    }

    if (objetoSemaforo.EstagioSemaforo == 1 && objetoSemaforo.tempo == 0) {
        objetoSemaforo.tempo = 10

    }

    if (objetoSemaforo.tempo >= 0) {
        objetoSemaforo.tempo--;
    }

    if (objetoSemaforo.EstagioSemaforo >= 2) {
        $(objetoSemaforo.labeltimeSemaforoPedestre).text("PARE");
        $(objetoSemaforo.labelTimeSemafoto).text(objetoSemaforo.tempo);
        $(objetoSemaforo.labelTimeSemafoto).removeClass("classePare");
    }

    if (objetoSemaforo.EstagioSemaforo == 1) {
        $(objetoSemaforo.labelTimeSemafoto).text("PARE");
        $(objetoSemaforo.labeltimeSemaforoPedestre).removeClass("classePare");
        $(objetoSemaforo.labeltimeSemaforoPedestre).text(objetoSemaforo.tempo);
    }



    objetoSemaforo.timeSetControl = setTimeout(objetoSemaforo.IniciaTime, 1000);
}





$(function () {
    objetoSemaforo.MotaEstagioSemafotos();



});